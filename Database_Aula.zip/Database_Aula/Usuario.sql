﻿/*
The bucket count should be set to about two times the 
maximum expected number of distinct values in the 
index key, rounded up to the nearest power of two.
*/

CREATE TABLE [dbo].[Usuario]
(
	[Id] INT NOT NULL PRIMARY KEY,
	[NomeUsuario] VARCHAR(255) NOT NULL, 
    [Ativo] BIT NOT NULL
) 

