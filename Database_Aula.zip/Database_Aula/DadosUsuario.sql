﻿CREATE TABLE [dbo].[DadosUsuario]
(
	[Idusuario] INT NOT NULL, 
    [Endereco] VARCHAR(255) NOT NULL, 
    [Idade] INT NOT NULL, 
    [Observacao] VARCHAR(5000) NULL, 
    CONSTRAINT [FK_DadosUsuario_Usuario] FOREIGN KEY ([Idusuario]) REFERENCES [Usuario]([Id]) 
)
